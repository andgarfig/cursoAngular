import {Injectable} from '@angular/core';

@Injectable()
export class RopaService {
  public nombrePrenda = 'Pantalones';
  public coleccionRopa = ['Pantalones Blancos', 'Polera Puma'];


  prueba(value) {
     //return this.nombrePrenda;
    return value;
   }

   addRopa(prenda):Array<string> {
    this.coleccionRopa.push(prenda);
    return this.getRopa();
   }

   eliminarRopa(indice){
    this.coleccionRopa.splice(indice, 1);
    return this.getRopa();
   }

   getRopa() {
    return this.coleccionRopa;
   }
}
