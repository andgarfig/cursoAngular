import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-fruta',
  templateUrl: './fruta.component.html',
  /*template: `
    <h2>Componente Fruta</h2>
    <p>Naranja, Manzana, Pera</p>
  `*/
})
//export class FrutaComponent {
export class FrutaComponent implements OnInit {
  titulo = 'Componente Frutas';
  // listadoFruta = 'Manzana, Pera, Papaya';

  // public o private hola: string = "Hola"

  /*nombre:string = 'Andres';
  edad:number = 33;
  mayorEdad:boolean = true;
  comodin: any = 123;*/

  nombre:string;
  edad:number;
  mayorEdad:boolean;
  comodin: any;

  /*arrayUno: Array<string> = ['a','b','c'];
  //arrayUno: Array<string> = ['a','b','c'];
  //arrayUno: string[] = ['a','b','c'];
  //arrayUno: Array<string|number> = ['a', 1, 'b', 2, 'c'];
  arrayDos: (string|number)[] = ['1', 2, 3];
  arraytres: Array<any> = ['a',1];*/

  listadoFruta: Array<string> = ['Manzana', 'Pera', 'Papaya'];

  constructor() {
    this.nombre ='Andres';
    this.edad = 33;
    this.mayorEdad = true;
    this.comodin = 'Comodin';

    console.log(this.listadoFruta);

    //this.holaMundo();
  }

  ngOnInit() {
    console.log(this.nombre);

    var uno = 1;
    var dos = 2;

    if(uno == 1 ){
      let uno = 11;
      var dos = 22;

      console.log('Dentro de IF', uno);
    }
    console.log('Fuera de IF', uno);

    const constante = 0;
    // constante = 1;

    console.log('constante', constante);


  }

  /*holaMundo() {
    alert('Hola Mundo');
  }*/

}
