import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
})

export class ContactoComponent implements OnInit {
  titulo = 'Componente Contacto';
  public parametro;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) { }

  redirigir(){
    this.router.navigate(['/contacto', 'conParametro']);  }
  ngOnInit() {
    //this.route.params.forEach(function(params: Params){
    this.route.params.forEach((params: Params) => {
      console.log(params);
      this.parametro = params['page'];
    });
  }
}
