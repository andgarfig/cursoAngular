import {Component, OnInit} from '@angular/core';
import {EmpleadoModel} from '../models/empleado.model';

@Component({
  selector: 'app-empleado',
  templateUrl: './empleado.component.html',
  styleUrls: ['./empleado.component.scss']
})
export class EmpleadoComponent implements OnInit {
  public titulo = 'Componente Empleado';
  public empleado: EmpleadoModel;
  public listaEmpleados: Array<EmpleadoModel>;

  public trabajador_externo: boolean = false;
  public color:string;

  public colorSeleccionado:string;

  constructor() {
    this.empleado = new EmpleadoModel('Andres', 33, true);
    this.listaEmpleados = [
      new EmpleadoModel('Jonathan', 35, false),
      new EmpleadoModel('Yeri', 27, true),
      new EmpleadoModel('Aurelio', 56, false)
    ];

    //this.color = 'red';
    //this.color = 'green';
    this.color = 'blue';
    this.colorSeleccionado = '#ccc'
  }


  cambiarExterno(valor:boolean){
    this.trabajador_externo = valor;
  }

  ngOnInit() {
    /*this.empleado = new EmpleadoModel();
    this.empleado.nombre = 'Andres';
    this.empleado.edad = 33;
    this.empleado.contratado = true;*/
    console.log('Empleado', this.empleado);
  }

}
