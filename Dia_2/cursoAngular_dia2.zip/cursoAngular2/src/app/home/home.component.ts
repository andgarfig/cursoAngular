import {Component, OnInit} from '@angular/core';
import {RopaService} from '../services/ropa.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  providers: [RopaService]
})

export class HomeComponent implements OnInit {
  titulo = 'Componente Home';
  public listadoRopa: string[];
  public prendaGuardar: string;

  //para pipes
  public fecha: any;

  constructor(private ropaService: RopaService) {
    this.fecha = new Date();
  }

  guardarPrenda() {
    this.ropaService.addRopa(this.prendaGuardar);
    this.prendaGuardar = null;
  }

  eliminarPrenda(index) {
    this.ropaService.eliminarRopa(index);
  }

  ngOnInit() {
    // console.log(this.ropaService.prueba());
    // console.log(this.ropaService.prueba('Polera Nike'));

    this.listadoRopa = this.ropaService.getRopa();
    console.log(this.listadoRopa);

  }
}
