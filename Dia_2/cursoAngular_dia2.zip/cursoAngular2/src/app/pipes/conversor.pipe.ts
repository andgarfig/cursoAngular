import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'conversor'})

export class ConversorPipe implements PipeTransform {
  transform(x, y) {
    let uno = parseInt(x);
    let dos = parseInt(y);

    let resultado = 'La multiplicacion: ' + uno + ' x ' + dos + ' = ' + (uno * dos);

    return resultado;
  }
}
