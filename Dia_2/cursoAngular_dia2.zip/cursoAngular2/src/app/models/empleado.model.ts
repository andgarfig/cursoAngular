export class EmpleadoModel {

  /*public nombre: string;
  public edad: number;
  public contratado: boolean;

  constructor(nombre, edad, contratado) {
    this.nombre = nombre;
    this.edad = edad;
    this.contratado = contratado;
  }*/

  /*public nombre:string;
  public edad:number;
  public contratado:boolean;

  constructor() {}*/

  constructor(
    public nombre:string,
    public edad:number,
    public contratado:boolean
  ) { }
}
